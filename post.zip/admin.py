from django.contrib import admin
from .models import Post, Result

admin.site.register(Post)

admin.site.register(Result)
# Register your models here.
